import React, { useState, useRef, useEffect } from 'react';
import { 
  Aperture,       FlaskConical,   Scan,           ArrowLeft,
  Loader2,        X,              Maximize2,      Plus,
  BookOpen,       Lightbulb,      TrendingUp,     Building2,
  Quote,          ListChecks,     PieChart,       Brain,
  Moon,           Sun,            Link,           ArrowRight,
  Sparkles,       MessageCircleQuestion, HelpCircle,
  RotateCw,       Coffee,         Camera,         CornerDownLeft,
  Home,           Search,         Grid,           ArrowUp,
  Wand2,          AlertTriangle,  Scale,          Zap,
  RefreshCw,      LightbulbOff,   Target,         Feather,
  CheckCircle2,   XCircle,        ClipboardList,  ArrowRightCircle,
  MessageSquareText, Send,        ChevronDown,    ChevronUp,
  Dices,          Microscope,     Image as ImageIcon,
  BarChart3,      Wifi,           WifiOff,        Layers
} from 'lucide-react';
import { 
  SlotConfig, Concept, DeepDiveData, QuizQuestion, 
  ProvokeData, ExtraAnalysisCard, ExtraProvocationCard, QAItem, Theme
} from './types';

// --- SLOT MACHINE DATA ---
const SLOT_DATA = {
  domains: [
    "Tâm lý học hành vi", "Lý thuyết trò chơi", "Sinh học tiến hóa", 
    "Chiến tranh tâm lý", "Triết học khắc kỷ", "Vật lý lượng tử (ứng dụng tư duy)", 
    "Hệ thống phức hợp", "Marketing du kích", "Kinh tế học vĩ mô", 
    "Xã hội học", "Tội phạm học", "Thiết kế trải nghiệm", 
    "Sử học (các bài học sụp đổ)", "Toán học (xác suất)", "Nghệ thuật đàm phán",
    "Tư duy điệp viên (CIA/KGB)", "Quy luật quyền lực", "Khoa học thần kinh"
  ],
  vibes: [
    "Nghịch lý", "Phản trực giác", "Đen tối/Tàn nhẫn", 
    "Tối giản/Lười biếng", "Gây tranh cãi", "Bí mật/Ít người biết", 
    "Nguy hiểm", "Hài hước/Châm biếm", "Khai sáng/Sốc", 
    "Thực dụng tàn bạo", "Điên rồ nhưng hiệu quả", "Lạnh lùng/Logic"
  ],
  contexts: [
    "để thao túng người khác", "để làm ít hưởng nhiều", "trong tình yêu/hẹn hò", 
    "để tránh bị lừa đảo", "để thăng tiến thần tốc", "khi đang bế tắc sáng tạo", 
    "để quản lý sếp", "để chiến thắng tranh luận", "để kiếm tiền thụ động", 
    "để hạnh phúc mà không cần cố gắng", "để nhìn thấu tâm can người khác",
    "để sống sót trong khủng hoảng", "để xây dựng sức ảnh hưởng"
  ]
};

// --- ANALYSIS LENSES ---
const ANALYSIS_LENSES = [
  "Góc nhìn Tiền bạc (ROI/Kinh tế)", 
  "Góc nhìn Tâm lý học đen tối (Dark Psychology)",
  "Góc nhìn Lịch sử (Bài học từ quá khứ)", 
  "Góc nhìn Tương lai (Futurism/AI)",
  "Góc nhìn chuyên gia triển khai", 
  "Góc nhìn Đạo đức & Triết học",
  "Góc nhìn Kẻ Lãnh Đạo", 
  "Góc nhìn Hệ thống (Systems Thinking)",
  "Góc nhìn ngẫu nhiên của chuyên gia",
  "Góc nhìn Rủi ro (Black Swan)",
  "Góc nhìn Đối thủ cạnh tranh"
];

// --- HELPER: REMOVE PARENTHESES ---
const cleanLabel = (text: string | undefined): string => {
  if (!text) return "";
  return text.replace(/[()]/g, '').trim();
};

// --- COMPONENT: TEXT RENDERER ---
interface TextRendererProps {
  content: string | undefined | null;
  className?: string;
  paragraphClass?: string;
}

const TextRenderer: React.FC<TextRendererProps> = ({ content, className = "", paragraphClass = "text-[15px]" }) => {
  if (!content || typeof content !== 'string') return null;

  let processed = content.replace(/\\n/g, '\n');
  const paragraphs = processed.split('\n').filter(p => p.trim() !== '');

  return (
    <div className={className}>
      {paragraphs.map((paragraph, index) => {
         let isHeader = false;
         let cleanText = paragraph;
         if (paragraph.startsWith('### ')) { isHeader = true; cleanText = paragraph.replace('### ', ''); }
         else if (paragraph.startsWith('## ')) { isHeader = true; cleanText = paragraph.replace('## ', ''); }
         
         const baseStyle = isHeader ? `font-bold text-[16px] mt-4 mb-2 block` : `mb-3 last:mb-0 leading-relaxed ${paragraphClass}`;

         return (
            <p key={index} className={baseStyle}>
              {cleanText.split(/(\*\*.*?\*\*|\*.*?\*)/g).map((part, i) => {
                if (part.startsWith('**') && part.endsWith('**')) {
                  return <strong key={i} className="font-bold">{part.slice(2, -2)}</strong>;
                }
                if (part.startsWith('*') && part.endsWith('*')) {
                  return <em key={i} className="italic">{part.slice(1, -1)}</em>;
                }
                return <span key={i}>{part}</span>;
              })}
            </p>
         );
      })}
    </div>
  );
};

// --- COMPONENT: DIFFICULTY BADGE (STANDARDIZED) ---
interface DifficultyBadgeProps {
  level: number;
  label: string;
  isDarkMode: boolean;
}

const DifficultyBadge: React.FC<DifficultyBadgeProps> = ({ level, label, isDarkMode }) => {
  const normalizedLevel = Math.max(1, Math.min(5, level || 3));
  
  // Unified color scheme (Indigo based)
  const activeClass = isDarkMode ? "bg-indigo-400" : "bg-indigo-600";
  const inactiveClass = isDarkMode ? "bg-white/10" : "bg-black/5";
  const textClass = isDarkMode ? "text-indigo-300" : "text-indigo-700";

  return (
    <div className={`flex items-center gap-2 px-3 py-1 rounded-full backdrop-blur-md ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white/40 border-black/5'} border shadow-sm flex-shrink-0`}>
       <div className="flex items-end gap-0.5 h-3">
          {[...Array(5)].map((_, i) => {
             const height = (i + 1) * 20 + '%';
             const isActive = i < normalizedLevel;
             return (
                <div 
                   key={i} 
                   className={`w-1 rounded-[1px] transition-all duration-500 ${isActive ? activeClass : inactiveClass}`} 
                   style={{ height: height }}
                />
             );
          })}
       </div>
       <span className={`text-[10px] font-bold uppercase tracking-wider ${textClass}`}>
          {cleanLabel(label) || "Trung bình"}
       </span>
    </div>
  );
};

export default function App() {
  // --- STATE ---
  const [apiKey, setApiKey] = useState<string>('');
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'error'>('connecting');
  const [images, setImages] = useState<string[]>([]); 
  const [loading, setLoading] = useState(false);
  const [imageLoading, setImageLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(''); 
  const [concept, setConcept] = useState<Concept | null>(null);
  
  const [deepDiveData, setDeepDiveData] = useState<DeepDiveData | null>(null);
  const [isDeepDiveMode, setIsDeepDiveMode] = useState(false);
  
  const [extraAnalysisCards, setExtraAnalysisCards] = useState<ExtraAnalysisCard[]>([]);
  const [loadingExtraAnalysis, setLoadingExtraAnalysis] = useState(false);

  const [realLifeExample, setRealLifeExample] = useState('');
  const [loadingExample, setLoadingExample] = useState(false);
  
  const [loadingCaseStudy, setLoadingCaseStudy] = useState(false);
  const [loadingInsight, setLoadingInsight] = useState(false);

  const [quizData, setQuizData] = useState<QuizQuestion[]>([]); 
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [loadingQuiz, setLoadingQuiz] = useState(false);
  const [userAnswers, setUserAnswers] = useState<{[key: number]: number}>({}); 

  const [provokeData, setProvokeData] = useState<ProvokeData | null>(null);
  const [extraProvocations, setExtraProvocations] = useState<ExtraProvocationCard[]>([]); 
  const [loadingExtraProvoke, setLoadingExtraProvoke] = useState(false);
  const [isProvokeMode, setIsProvokeMode] = useState(false);

  const [suggestedTopics, setSuggestedTopics] = useState<string[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);

  const [isQAModalOpen, setIsQAModalOpen] = useState(false);
  const [qaQuery, setQaQuery] = useState('');
  const [loadingQA, setLoadingQA] = useState(false);
  const [qaList, setQaList] = useState<QAItem[]>([]); 

  const [error, setError] = useState('');
  const [lightboxImg, setLightboxImg] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');
  
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [slotResult, setSlotResult] = useState<SlotConfig | null>(null);

  const contentRef = useRef<HTMLDivElement>(null);
  const provokeRef = useRef<HTMLDivElement>(null);
  const bottomProvokeRef = useRef<HTMLDivElement>(null);
  const quizRef = useRef<HTMLDivElement>(null);
  const qaSectionRef = useRef<HTMLDivElement>(null); 
  const extraAnalysisEndRef = useRef<HTMLDivElement>(null);

  // --- FETCH API KEY ---
  useEffect(() => {
    const fetchApiKey = async () => {
      try {
        setConnectionStatus('connecting');
        const response = await fetch("https://data.rayma.vn/api.php?profile=google_api_data");
        const data = await response.json();
        let keys: string[] = [];
        if (Array.isArray(data)) {
          const extractedKeys = data
            .filter((item: any) => item && typeof item === 'object' && item.apikey)
            .map((item: any) => item.apikey);
          if (extractedKeys.length > 0) keys = extractedKeys;
          else {
            const stringKeys = data.filter((item: any) => typeof item === 'string');
            if (stringKeys.length > 0) keys = stringKeys;
          }
        } else if (data && typeof data === 'object') {
          if (Array.isArray(data.data)) keys = data.data;
          else if (Array.isArray(data.keys)) keys = data.keys;
          else if (Object.values(data).every(val => typeof val === 'string')) keys = Object.values(data) as string[];
        }
        keys = keys.filter(k => typeof k === 'string' && k.length > 10);
        if (keys.length > 0) {
          const randomKey = keys[Math.floor(Math.random() * keys.length)];
          setApiKey(randomKey);
          setConnectionStatus('connected');
        } else {
          setConnectionStatus('error');
        }
      } catch (err) {
        setConnectionStatus('error');
      }
    };
    fetchApiKey();
  }, []);

  // --- HELPER: CLEAN JSON ---
  const cleanAndParseJSON = (text: string | undefined): any => {
    try {
      if (!text) return null;
      const match = text.match(/\{[\s\S]*\}/);
      const cleaned = match ? match[0] : text.replace(/```json|```/g, '').trim();
      return JSON.parse(cleaned);
    } catch (e) {
      console.error("JSON Error:", text);
      return null;
    }
  };

  // --- THEME & STYLES (STANDARDIZED) ---
  const theme = {
    bg: isDarkMode ? "bg-[#050505]" : "bg-[#F0F2F5]", // Slightly lighter/cleaner bg for light mode
    text: isDarkMode ? "text-gray-100" : "text-[#1D1D1F]",
    subText: isDarkMode ? "text-gray-400" : "text-[#6e6e73]",
    // Primary accent used for branding (Indigo/Violet)
    primary: isDarkMode ? "text-indigo-400" : "text-indigo-600",
    primaryBg: isDarkMode ? "bg-indigo-500" : "bg-indigo-600",
  };

  // UNIFIED GLASS CARD STYLE
  const glassCardStyle = `
    backdrop-blur-xl 
    ${isDarkMode ? "bg-white/5 border-white/10" : "bg-white/60 border-white/40"} 
    border shadow-[0_4px_24px_-1px_rgba(0,0,0,0.05)] 
    rounded-[24px] 
    transition-all duration-500 
    hover:shadow-[0_8px_32px_-1px_rgba(0,0,0,0.08)]
  `;

  // --- API CALLS ---
  const brainstormLesson = async (userGuidance = '', slotConfig: SlotConfig | null = null) => {
    if (!apiKey) throw new Error("API Key chưa sẵn sàng. Vui lòng đợi.");
    try {
      setLoadingStep('brainstorming');
      let taskInstruction = "";
      if (userGuidance.trim()) {
        taskInstruction = `NHIỆM VỤ: Giải thích CHÍNH XÁC khái niệm: "${userGuidance}". KHÔNG ĐỔI CHỦ ĐỀ.`;
      } else if (slotConfig) {
        taskInstruction = `
          NHIỆM VỤ: Đóng vai Curator. Tìm KHÁI NIỆM/ĐỊNH LUẬT/HIỆU ỨNG thỏa mãn:
          1. Lĩnh vực: ${slotConfig.domain}
          2. Tính chất: ${slotConfig.vibe}
          3. Áp dụng cho: ${slotConfig.context}
          Chủ đề thú vị, Niche, "Mind-blowing".
        `;
      } else {
        taskInstruction = `NHIỆM VỤ: Chọn ngẫu nhiên một khái niệm SIÊU MỚI LẠ.`;
      }
      const prompt = `
        ĐÓNG VAI MỘT NGƯỜI BẠN THÔNG THÁI TẠI "LAZY LEARN LAB".
        ${taskInstruction}
        (Random Seed: ${Date.now()})
        QUAN TRỌNG:
        1. "visualPrompt": Mô tả các HÌNH KHỐI TRỪU TƯỢNG (spheres, cubes, cones...) sắp xếp nghệ thuật. Minimalist. NO TEXT.
        2. "detailedExplanation": Giải thích siêu dễ hiểu, bình dân. ĐI THẲNG VÀO VẤN ĐỀ. In đậm ý chính.
        3. "category": Danh mục phải là Tiếng Việt, TỐI ĐA 2 TỪ, KHÔNG dùng dấu ngoặc đơn (VD: Tâm Lý, Kinh Tế).
        4. "tag": Tag mô tả ngắn gọn Tiếng Việt, TỐI ĐA 3 TỪ, KHÔNG dấu ngoặc đơn.
        5. "difficulty": Label độ khó Tiếng Việt, 1-2 từ (VD: Dễ, Khó, Vừa), KHÔNG dấu ngoặc đơn.
        6. "relatedConcepts": 8 bài học liên quan.
        
        Trả về JSON: { "category": "...", "titleEn": "...", "titleVn": "...", "tag": "...", "shortLesson": "...", "detailedExplanation": "...", "visualPrompt": "...", "difficulty": { "level": 3, "label": "..." }, "relatedConcepts": [{"vn": "...", "en": "..."}] }
      `;
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json" } }) });
      const data = await response.json();
      return cleanAndParseJSON(data.candidates?.[0]?.content?.parts?.[0]?.text);
    } catch (e) { throw new Error("Hệ thống đang bận, thử lại sau nhé."); }
  };

  const generateDeepDiveContent = async (currentConcept: Concept) => {
    if (!apiKey) return null;
    try {
      const prompt = `
        PHÂN TÍCH SÂU KHÁI NIỆM: "${currentConcept.titleEn}" (${currentConcept.titleVn}).

        YÊU CẦU NỘI DUNG NGHIÊM NGẶT:
        1. "realLifeExample": Ví dụ phải cực kỳ ĐỜI THƯỜNG, BÌNH DÂN, HÀI HƯỚC (VD: chuyện đi chợ, vợ chồng cãi nhau, nuôi mèo, deadline, trà đá vỉa hè...). Cấm dùng ví dụ doanh nghiệp ở đây. Phải khiến người đọc cười và thấy mình trong đó.
        2. "matrix": Ma trận định vị 2x2. "xAxis" và "yAxis" là 2 yếu tố đánh đổi (VD: Liều vs. Lợi nhuận). QUAN TRỌNG: 4 góc phần tư (q1, q2, q3, q4) KHÔNG ĐƯỢC đặt tên là Q1, Q2... mà phải đặt tên là 4 KIỂU NGƯỜI / 4 TÌNH HUỐNG cụ thể (Persona/Archetype), ví dụ: "Kẻ Ngây Thơ", "Thánh Ăn May", "Con Bò Sữa". Nội dung "text" ngắn gọn, "slap in the face".
        3. "caseStudyTitle" & "caseStudyContent": Chọn một Case Study KINH ĐIỂN, CÓ THẬT của một thương hiệu/nhân vật cụ thể. Nêu rõ bối cảnh, hành động và kết quả. Phải có tính xác thực cao.
        4. "highlightStat": CHỈ GHI CON SỐ và ĐƠN VỊ (VD: "85%", "$10 Tỷ", "1/3"). Tuyệt đối không viết câu dài dòng ở đây.
        5. "stats": Giải thích con số trên nói lên điều gì.
        6. "source": Ghi rõ nguồn (Tên tổ chức/Báo cáo + Năm).
        7. "insight": Viết một câu chiêm nghiệm mang tính TRIẾT HỌC SÂU SẮC (Tone: Khắc kỷ/Thiền/Hiện sinh). Dùng hình ảnh ẩn dụ, ngắn gọn (dưới 25 từ), súc tích nhưng "thấm". Không dùng lời khuyên sáo rỗng.
        
        Trả về JSON: 
        { "realLifeExample": "...", "matrix": { "yAxis": "...", "xAxis": "...", "q1": {"label": "...", "text": "..."}, "q2": {"label": "...", "text": "..."}, "q3": {"label": "...", "text": "..."}, "q4": {"label": "...", "text": "..."}, "analysis": "..." }, "caseStudyTitle": "...", "caseStudyContent": "...", "highlightStat": "...", "stats": "...", "source": "...", "pitfalls": ["...", "..."], "actions": ["...", "..."], "insight": "..." }
      `;
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json" } }) });
      const data = await response.json();
      return cleanAndParseJSON(data.candidates?.[0]?.content?.parts?.[0]?.text);
    } catch (e) { throw new Error("Không thể trích xuất dữ liệu."); }
  };

  const generateMoreAnalysis = async () => {
    if (!concept || !apiKey) return;
    try {
      setLoadingExtraAnalysis(true);
      const randomLens = ANALYSIS_LENSES[Math.floor(Math.random() * ANALYSIS_LENSES.length)];
      const prompt = `Phân tích "${concept.titleEn}" dưới lăng kính: "${randomLens}". JSON: { "title": "...", "lens": "${randomLens}", "content": "..." }`;
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json" } }) });
      const data = await response.json();
      const newAnalysis = cleanAndParseJSON(data.candidates?.[0]?.content?.parts?.[0]?.text);
      setExtraAnalysisCards(prev => [...prev, newAnalysis]);
      setTimeout(() => { extraAnalysisEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 200);
    } catch (e) { console.error(e); } finally { setLoadingExtraAnalysis(false); }
  };

  const refreshRealLifeExample = async (currentConcept: Concept) => {
    if (!apiKey) return;
    try {
      setLoadingExample(true);
      const prompt = `Khái niệm: "${currentConcept.titleEn}". Hãy tìm một Ví dụ đời thường MỚI, phải HÀI HƯỚC, BÌNH DÂN (chuyện yêu đương, gia đình, bạn bè). JSON: { "example": "..." }`;
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json" } }) });
      const data = await response.json();
      setRealLifeExample(cleanAndParseJSON(data.candidates?.[0]?.content?.parts?.[0]?.text).example);
    } catch (e) { console.error(e); } finally { setLoadingExample(false); }
  };

  const refreshCaseStudy = async (currentConcept: Concept) => {
    if (!apiKey) return;
    try {
      setLoadingCaseStudy(true);
      const prompt = `Khái niệm: "${currentConcept.titleEn}". Tìm một Case Study KHÁC. Phải là sự kiện/công ty CÓ THẬT, nổi tiếng. JSON: { "title": "...", "content": "..." }`;
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json" } }) });
      const data = await response.json();
      const newCase = cleanAndParseJSON(data.candidates?.[0]?.content?.parts?.[0]?.text);
      setDeepDiveData(prev => prev ? ({ ...prev, caseStudyTitle: newCase.title, caseStudyContent: newCase.content }) : null);
    } catch (e) { console.error(e); } finally { setLoadingCaseStudy(false); }
  };

  const refreshInsightQuote = async (currentConcept: Concept) => {
    if (!apiKey) return;
    try {
      setLoadingInsight(true);
      const prompt = `Khái niệm: "${currentConcept.titleEn}". Hãy viết một câu triết lý SÂU SẮC, SÚC TÍCH, mang tính chiêm nghiệm về bản chất con người/cuộc đời. Dùng ẩn dụ hình ảnh. Không giáo điều. JSON: { "insight": "..." }`;
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json" } }) });
      const data = await response.json();
      setDeepDiveData(prev => prev ? ({ ...prev, insight: cleanAndParseJSON(data.candidates?.[0]?.content?.parts?.[0]?.text).insight }) : null);
    } catch (e) { console.error(e); } finally { setLoadingInsight(false); }
  };

  const generateQuiz = async (isNext = false) => {
    if (!concept || !apiKey) return;
    try {
      setLoadingQuiz(true);
      if (!isNext) { setQuizData([]); setCurrentQuestionIndex(0); setUserAnswers({}); }
      const prompt = `Khái niệm: "${concept.titleEn}". 1 câu trắc nghiệm (A,B,C,D). JSON: { "question": "...", "options": ["..."], "correctIndex": 0, "explanation": "..." }`;
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json" } }) });
      const data = await response.json();
      const newQuestion = cleanAndParseJSON(data.candidates?.[0]?.content?.parts?.[0]?.text);
      setQuizData(prev => isNext ? [...prev, newQuestion] : [newQuestion]);
      if (isNext) { setCurrentQuestionIndex(prev => prev + 1); }
      setTimeout(() => { quizRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 100);
    } catch (e) { console.error(e); } finally { setLoadingQuiz(false); }
  };

  const handleAnswerSelect = (optIndex: number) => {
      if (userAnswers[currentQuestionIndex] !== undefined) return; 
      setUserAnswers(prev => ({ ...prev, [currentQuestionIndex]: optIndex }));
  };
  
  const handleNextQuestion = () => { generateQuiz(true); };

  const generateProvokeQuestions = async (currentConcept: Concept) => {
    if (!apiKey) return null;
    try {
      const prompt = `Khái niệm: "${currentConcept.titleEn}". COACH tâm lý. Câu hỏi tự vấn. JSON: { "questions": ["..."], "counter_argument": "...", "mini_challenge": "..." }`;
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json" } }) });
      const data = await response.json();
      return cleanAndParseJSON(data.candidates?.[0]?.content?.parts?.[0]?.text);
    } catch (e) { throw new Error("Lỗi tạo gợi mở."); }
  };

  const generateMoreProvocations = async () => {
    if (!concept || !apiKey) return;
    try {
      setLoadingExtraProvoke(true);
      const perspectives = ["Khách hàng khó tính", "Đối thủ", "Nhân viên", "Bản thân 10 tuổi", "Sếp"];
      const randomPerspective = perspectives[Math.floor(Math.random() * perspectives.length)];
      const prompt = `Khái niệm: "${concept.titleEn}". Góc nhìn: ${randomPerspective}. Thách thức người dùng. JSON: { "title": "Góc nhìn từ ${randomPerspective}", "content": "..." }`;
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json" } }) });
      const data = await response.json();
      const newCard = cleanAndParseJSON(data.candidates?.[0]?.content?.parts?.[0]?.text);
      setExtraProvocations(prev => [...prev, newCard]);
      setTimeout(() => { bottomProvokeRef.current?.scrollIntoView({ behavior: 'smooth' }); }, 100);
    } catch (e) { console.error("Lỗi tạo thêm:", e); } finally { setLoadingExtraProvoke(false); }
  };

  const generateImageCall = async (prompt: string) => {
    if (!apiKey) return null;
    try {
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/imagen-4.0-generate-001:predict?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ instances: [{ prompt }], parameters: { sampleCount: 1, aspectRatio: "1:1" } }) });
      const result = await response.json();
      return result.predictions?.[0]?.bytesBase64Encoded ? `data:image/png;base64,${result.predictions[0].bytesBase64Encoded}` : null;
    } catch (err) { return null; }
  };

  const generateTopicSuggestions = async () => {
    if (!apiKey) return;
    try {
      setLoadingSuggestions(true);
      const prompt = `Đề xuất 10 chủ đề học tập ngắn gọn (2-5 từ). JSON: { "topics": ["..."] }`;
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json" } }) });
      const data = await response.json();
      setSuggestedTopics(cleanAndParseJSON(data.candidates?.[0]?.content?.parts?.[0]?.text).topics);
    } catch (e) { console.error(e); } finally { setLoadingSuggestions(false); }
  };

  const handleQASubmit = async () => {
    if (!qaQuery.trim() || !concept || !apiKey) return;
    setLoadingQA(true);
    try {
      const prompt = `Ngữ cảnh: "${concept.titleVn}". Người dùng hỏi: "${qaQuery}". Trả lời ngắn gọn, dễ hiểu.`;
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${apiKey}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }) });
      const data = await response.json();
      const answer = data.candidates?.[0]?.content?.parts?.[0]?.text;
      const newQA = { id: Date.now(), question: qaQuery, answer: answer || "Xin lỗi, mình chưa nghĩ ra câu trả lời.", isOpen: true };
      setQaList(prev => [...prev, newQA]);
      setQaQuery(''); setIsQAModalOpen(false); 
      setTimeout(() => { qaSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 300);
    } catch (e) { console.error(e); } finally { setLoadingQA(false); }
  };

  const toggleQA = (id: number) => { setQaList(prev => prev.map(item => item.id === id ? { ...item, isOpen: !item.isOpen } : item)); };

  const executeGeneration = async (guidance = '') => {
    if (loading) return;
    if (!apiKey) { setError("Đang kết nối đến máy chủ AI, vui lòng thử lại sau giây lát..."); return; }
    setLoading(true); setError(''); setImages([]); setImageLoading(true); 
    setIsDeepDiveMode(false); setIsProvokeMode(false); setConcept(null); setDeepDiveData(null); setProvokeData(null); setRealLifeExample(''); setExtraProvocations([]); setQuizData([]); setCurrentQuestionIndex(0); setIsModalOpen(false); setIsQAModalOpen(false); setQaQuery(''); setQaList([]); setSlotResult(null); setExtraAnalysisCards([]); 
    
    let slotConfig = null;
    if (!guidance || guidance.trim() === '') {
        const domain = SLOT_DATA.domains[Math.floor(Math.random() * SLOT_DATA.domains.length)];
        const vibe = SLOT_DATA.vibes[Math.floor(Math.random() * SLOT_DATA.vibes.length)];
        const context = SLOT_DATA.contexts[Math.floor(Math.random() * SLOT_DATA.contexts.length)];
        slotConfig = { domain, vibe, context };
        setSlotResult(slotConfig); 
    }
    try {
      const newConcept = await brainstormLesson(guidance, slotConfig);
      if (!newConcept) throw new Error("Không tạo được bài học");
      setConcept(newConcept); setLoading(false);
      const imagePrompt = `Abstract 3D Geometric Art representing: "${newConcept.visualPrompt}". Style: Dark Surrealism, Cinematic Lighting, Monochromatic Indigo.`;
      generateImageCall(imagePrompt).then(img => { if (img) setImages([img]); setImageLoading(false); }).catch(err => { setImageLoading(false); });
    } catch (e: any) { setError(e.message); setLoading(false); setImageLoading(false); } 
  };

  const handleDeepDive = async (e: React.MouseEvent) => { 
    e?.stopPropagation(); 
    if (loading || !concept) return; 
    if (isDeepDiveMode) { setIsDeepDiveMode(false); } else { 
        setIsProvokeMode(false); 
        if (!deepDiveData) { 
            setLoading(true); setLoadingStep('analyzing'); 
            try { 
                const d = await generateDeepDiveContent(concept); 
                if(d) { setDeepDiveData(d); setRealLifeExample(d.realLifeExample); setIsDeepDiveMode(true); setTimeout(()=>contentRef.current?.scrollIntoView({behavior:'smooth',block:'start'}),100); } else { setError("Lỗi dữ liệu phân tích."); }
            } catch(e){ setError("Lỗi phân tích dữ liệu."); } finally { setLoading(false); setLoadingStep(''); } 
        } else { setIsDeepDiveMode(true); setTimeout(()=>contentRef.current?.scrollIntoView({behavior:'smooth',block:'start'}),100); } 
    } 
  };

  const handleProvoke = async (e: React.MouseEvent) => { 
    e?.stopPropagation(); 
    if (loading || !concept) return; 
    if (isProvokeMode) { setIsProvokeMode(false); } else { 
        setIsDeepDiveMode(false); 
        if (!provokeData) { 
            setLoading(true); setLoadingStep('provoke'); 
            try { 
                const d = await generateProvokeQuestions(concept); 
                if(d) { setProvokeData(d); setIsProvokeMode(true); setTimeout(()=>provokeRef.current?.scrollIntoView({behavior:'smooth',block:'start'}),100); } else { setError("Lỗi dữ liệu gợi mở."); }
            } catch(e){ setError("Lỗi tạo câu hỏi gợi mở."); } finally { setLoading(false); setLoadingStep(''); } 
        } else { setIsProvokeMode(true); setTimeout(()=>provokeRef.current?.scrollIntoView({behavior:'smooth',block:'start'}),100); } 
    } 
  };

  const handleRefreshExample = async () => { if(loadingExample || !concept) return; await refreshRealLifeExample(concept); };
  const handleRefreshCaseStudy = async () => { if (loadingCaseStudy || !concept) return; await refreshCaseStudy(concept); };
  const handleRefreshInsight = async () => { if (loadingInsight || !concept) return; await refreshInsightQuote(concept); };
  const handleQAModalAction = () => { setIsQAModalOpen(true); };

  // --- RENDER ---
  return (
    <div className={`min-h-screen ${theme.bg} ${theme.text} font-sans selection:bg-indigo-100 dark:selection:bg-indigo-900/50 flex flex-col transition-colors duration-500`}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400;1,600&display=swap');
        .font-serif-display { font-family: 'Playfair Display', serif; } body { font-family: 'Inter', sans-serif; } 
        @keyframes fade-in { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } } 
        .animate-fade-in { animation: fade-in 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards; } 
        .animate-fade-in-up { animation: fade-in 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
      `}</style>
      
      {/* HEADER - GLASS & UNIFIED THEME - HEIGHT REDUCED to 44px */}
      <header className={`sticky top-0 z-20 backdrop-blur-xl border-b transition-all duration-500 shadow-[0_4px_30px_rgba(0,0,0,0.03)] ${isDarkMode ? "bg-black/30 border-white/10" : "bg-white/30 border-white/20"}`}>
        <div className="max-w-3xl mx-auto px-5 h-[44px] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {loading ? <Loader2 size={18} className={`animate-spin ${theme.primary}`} /> : <Brain size={18} strokeWidth={1.5} className={theme.primary} />}
            <span className="text-[15px] font-semibold tracking-tight">LAZY LEARN <span className={`font-light ${theme.subText}`}>LAB</span></span>
          </div>
          <div className="flex items-center gap-3">
             <div className="flex items-center justify-center w-7 h-7 rounded-full" title={connectionStatus === 'connected' ? "Đã kết nối API" : "Lỗi kết nối API"}>
                {connectionStatus === 'connected' ? <Wifi size={16} className="text-emerald-500" /> : connectionStatus === 'error' ? <WifiOff size={16} className="text-rose-500" /> : <Loader2 size={14} className={`animate-spin ${theme.primary}`} />}
             </div>
             <button onClick={() => setIsModalOpen(true)} disabled={loading} className={`p-1.5 rounded-full hover:bg-gray-200/50 dark:hover:bg-gray-800/50 transition-all active:scale-95 ${theme.subText} hover:text-current`}><Plus size={16} strokeWidth={2} /></button>
             <button onClick={() => setIsDarkMode(!isDarkMode)} className={`p-1.5 rounded-full hover:bg-gray-200/50 dark:hover:bg-gray-800/50 transition-all active:scale-95 ${theme.subText} hover:text-current`}>{isDarkMode ? <Sun size={16} strokeWidth={2} /> : <Moon size={16} strokeWidth={2} />}</button>
          </div>
        </div>
      </header>

      {/* MAIN CONTENT */}
      <main className="flex-1 w-full max-w-md md:max-w-2xl lg:max-w-3xl mx-auto px-5 py-8 pb-36">
        
        {!loading && !concept && !error && (
          <div className="flex flex-col items-center justify-center h-[60vh] animate-fade-in">
            <div className={`w-20 h-20 rounded-[24px] flex items-center justify-center shadow-[0_20px_40px_-10px_rgba(0,0,0,0.1)] mb-6 transition-colors duration-500 ${isDarkMode ? "bg-white/5 border border-white/10" : "bg-white border border-gray-100"}`}>
              <BookOpen size={36} strokeWidth={1} className={theme.primary} />
            </div>
            <h2 className="text-[22px] font-semibold tracking-tight mb-2">Lazy Learn Lab</h2>
            <p className={`text-[15px] ${theme.subText} text-center max-w-[260px] leading-relaxed`}>Học kiến thức kinh doanh thụ động qua hình khối trừu tượng và giải thích siêu đơn giản.</p>
            {!apiKey && <p className={`mt-4 text-[12px] font-medium animate-pulse flex items-center gap-2 ${theme.primary}`}><Loader2 size={12} className="animate-spin" />Đang kết nối máy chủ...</p>}
          </div>
        )}

        {loading && !concept && (
          <div className="flex flex-col items-center justify-center h-[50vh] animate-fade-in space-y-5">
            <Loader2 size={40} strokeWidth={1} className={`animate-spin ${theme.subText}`} />
            <p className={`text-[13px] font-medium uppercase tracking-widest ${theme.subText} animate-pulse`}>Đang chuẩn bị bài học...</p>
          </div>
        )}

        {concept && (
          <div className={`animate-fade-in-up transition-opacity duration-300 ${loading ? 'opacity-80' : 'opacity-100'}`}>
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                 <span className={`px-3 py-1 rounded-full backdrop-blur-md border ${isDarkMode ? "bg-white/5 border-white/10" : "bg-white/40 border-black/5"} text-[10px] font-bold uppercase tracking-wider ${theme.subText} shadow-sm flex items-center gap-1.5`}>
                    <TrendingUp size={10} className="flex-shrink-0" />{cleanLabel(concept.category)}
                 </span>
                 <DifficultyBadge level={concept.difficulty?.level || 3} label={concept.difficulty?.label || "Trung bình"} isDarkMode={isDarkMode} />
              </div>
              <h1 className={`text-[26px] leading-[1.2] font-bold tracking-tight mb-1 ${theme.text}`}>{concept.titleVn}</h1>
              <h2 className={`text-[15px] font-normal ${theme.subText} mb-3`}>{concept.titleEn}</h2>
              <span className={`text-[12px] font-medium ${isDarkMode ? "bg-white text-black" : "bg-black text-white"} px-2 py-0.5 rounded text-xs uppercase tracking-wide transition-colors`}>{cleanLabel(concept.tag)}</span>
            </div>

            <div className={`relative w-full aspect-square rounded-[22px] overflow-hidden border ${isDarkMode ? "border-white/10" : "border-gray-200"} shadow-2xl group mb-8 ${(isDeepDiveMode || isProvokeMode) ? 'scale-[0.98]' : ''}`} onClick={() => images.length > 0 && setLightboxImg(images[0])}>
              {imageLoading ? (
                  <div className={`absolute inset-0 flex flex-col items-center justify-center ${isDarkMode ? 'bg-gray-900' : 'bg-gray-100'} animate-pulse`}>
                      <Loader2 size={32} className={`animate-spin mb-2 ${theme.subText}`} /><span className={`text-[10px] uppercase tracking-widest ${theme.subText}`}>Đang vẽ minh họa...</span>
                  </div>
              ) : images.length > 0 ? (
                  <img src={images[0]} alt="Concept Art" className={`w-full h-full object-cover transition-all duration-500 cursor-zoom-in ${isDarkMode ? 'invert mix-blend-normal' : 'mix-blend-multiply'}`} />
              ) : ( <div className={`absolute inset-0 ${isDarkMode ? 'bg-gray-900' : 'bg-gray-50'}`}></div> )}
            </div>

            <div className={`${(isDeepDiveMode || isProvokeMode) ? 'hidden' : 'block'}`}>
                {/* UNIFIED CARD STYLE 1 */}
                <div className={`${glassCardStyle} p-6 mb-4`}>
                    <div className="flex items-center gap-2 mb-3"><Lightbulb size={16} className="text-amber-500 fill-amber-500" /><h3 className={`text-[11px] font-bold uppercase tracking-widest ${theme.subText}`}>Bài học cốt lõi</h3></div>
                    <p className={`text-[16px] ${theme.text} leading-relaxed font-medium`}>"{concept.shortLesson}"</p>
                </div>
                {/* UNIFIED CARD STYLE 2 */}
                <div className={`${glassCardStyle} p-6 mb-4`}>
                    <div className="flex items-center gap-2 mb-3"><BookOpen size={16} className={theme.primary} /><h3 className={`text-[11px] font-bold uppercase tracking-widest ${theme.subText}`}>Giải thích siêu dễ hiểu</h3></div>
                    <div className={`text-[15px] ${theme.subText} font-normal leading-relaxed`}><TextRenderer content={concept.detailedExplanation} /></div>
                </div>

                <div ref={qaSectionRef}>
                {qaList.map((qa) => (
                    <div key={qa.id} className={`animate-fade-in-up mb-4 rounded-[24px] overflow-hidden ${glassCardStyle}`}>
                        <button onClick={() => toggleQA(qa.id)} className={`w-full p-5 text-left flex items-start justify-between gap-4 transition-colors`}>
                            <div className="flex gap-3"><MessageSquareText size={18} className={`mt-0.5 flex-shrink-0 ${theme.primary}`} /><span className={`text-[14px] font-bold ${theme.text} leading-snug`}>{qa.question}</span></div>
                            {qa.isOpen ? <ChevronUp size={16} className={theme.subText} /> : <ChevronDown size={16} className={theme.subText} />}
                        </button>
                        {qa.isOpen && (<div className={`px-5 pb-5 pt-0 animate-fade-in`}><div className={`pl-8 pt-2 border-l-2 ${isDarkMode ? "border-white/10" : "border-black/5"} ml-2`}><div className={`text-[14px] leading-relaxed ${theme.subText}`}><TextRenderer content={qa.answer} /></div></div></div>)}
                    </div>
                ))}
                </div>
            </div>

             {/* PROVOKE CONTENT (STANDARDIZED) */}
             {isProvokeMode && provokeData && (
              <div ref={provokeRef} className="animate-fade-in-up mb-8 space-y-4">
                  <div>
                    <div className="flex items-center gap-2 mb-4 px-2"><Sparkles size={16} className={theme.primary} /><h3 className={`text-[13px] font-bold uppercase tracking-widest ${theme.subText}`}>Câu hỏi tự vấn</h3></div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {provokeData.questions.map((q, idx) => (
                        <div key={idx} className={`${glassCardStyle} p-5 relative overflow-hidden group`}>
                           <div className={`absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity ${theme.primary}`}><MessageCircleQuestion size={40} /></div>
                           <div className="flex gap-3 items-start relative z-10">
                              <span className={`text-[16px] font-serif-display italic opacity-50 ${theme.text} mt-0.5`}>{idx+1}.</span>
                              <div className={`text-[15px] font-medium ${theme.text}`}><TextRenderer content={q} /></div>
                           </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {provokeData.counter_argument && (
                     <div className={`${glassCardStyle} p-6`}>
                        <div className="flex items-center gap-2 mb-3"><Scale size={16} className="text-orange-500" /><h3 className="text-[11px] font-bold uppercase tracking-widest text-orange-500">Góc nhìn phản biện</h3></div>
                        <div className={`text-[15px] ${theme.text} italic border-l-2 ${isDarkMode ? "border-white/10" : "border-black/5"} pl-4`}><TextRenderer content={provokeData.counter_argument} /></div>
                     </div>
                  )}

                  {provokeData.mini_challenge && (
                     <div className={`${glassCardStyle} p-6`}>
                        <div className="flex items-center gap-2 mb-3"><Zap size={16} className="text-emerald-500" /><h3 className="text-[11px] font-bold uppercase tracking-widest text-emerald-500">Thử thách 24h</h3></div>
                        <div className={`text-[15px] ${theme.text} font-medium`}><TextRenderer content={provokeData.mini_challenge} /></div>
                     </div>
                  )}

                  {extraProvocations.map((card, idx) => (
                     <div key={`extra-${idx}`} className="animate-fade-in-up">
                        <div className={`${glassCardStyle} p-6`}>
                           <div className="flex items-center gap-2 mb-3"><LightbulbOff size={16} className={theme.primary} /><h3 className={`text-[11px] font-bold uppercase tracking-widest ${theme.primary}`}>{card.title}</h3></div>
                           <div className={`text-[15px] ${theme.text} font-medium`}><TextRenderer content={card.content} /></div>
                        </div>
                     </div>
                  ))}

                  <div ref={bottomProvokeRef} className="pt-2 flex justify-center pb-8">
                     <button onClick={generateMoreProvocations} disabled={loadingExtraProvoke} className={`flex items-center gap-2 px-5 py-2.5 rounded-full ${isDarkMode ? "bg-white/10 hover:bg-white/20" : "bg-black/5 hover:bg-black/10"} backdrop-blur-md transition-all active:scale-95 font-medium text-[13px] ${theme.text}`}>
                        {loadingExtraProvoke ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}<span>Gợi mở thêm</span>
                     </button>
                  </div>
              </div>
             )}

            {isDeepDiveMode && deepDiveData && (
              <div ref={contentRef} className="space-y-4 animate-fade-in-up">
                <div className={`${glassCardStyle} p-6 relative overflow-hidden`}>
                   <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none"><Coffee size={80} className={theme.text} /></div>
                   <div className="flex items-center justify-between mb-3 relative z-10">
                      <div className="flex items-center gap-2"><Coffee size={16} className={theme.primary} /><h3 className={`text-[11px] font-bold uppercase tracking-widest ${theme.primary}`}>Ví dụ đời thường</h3></div>
                      <button onClick={handleRefreshExample} disabled={loadingExample} className={`p-2 rounded-full hover:bg-gray-500/10 transition-all active:scale-90`}><RotateCw size={14} className={`${theme.primary} ${loadingExample ? 'animate-spin' : ''}`} /></button>
                   </div>
                   <div className="relative z-10 min-h-[60px] flex items-center">
                     {loadingExample ? (<div className="flex items-center gap-2 text-sm text-gray-400"><Loader2 size={14} className="animate-spin" /><span>Đang nghĩ ví dụ mới...</span></div>) : (<div className={`text-[15px] ${theme.text} font-medium`}><TextRenderer content={realLifeExample} /></div>)}
                   </div>
                </div>

                {deepDiveData.matrix && (
                  <div className={`${glassCardStyle} p-6 pb-8`}>
                    <div className="flex items-center gap-2 mb-4"><Grid size={16} className={theme.primary} /><h3 className={`text-[11px] font-bold uppercase tracking-widest ${theme.subText}`}>Ma Trận Chiến Lược</h3></div>
                    <div className="relative pl-6 pb-6">
                        <div className="absolute left-0 top-0 bottom-6 w-4 flex items-center justify-center"><div className="transform -rotate-90 flex items-center gap-2 whitespace-nowrap"><span className="text-[8px] font-bold uppercase tracking-wider text-gray-400">{deepDiveData.matrix.yAxis}</span><ArrowRight size={10} className="text-gray-400" /></div></div>
                        <div className="grid grid-cols-2 gap-2">
                            {['q2', 'q1', 'q3', 'q4'].map((key) => { const k = key as 'q1' | 'q2' | 'q3' | 'q4'; const quadrant = deepDiveData.matrix?.[k]; return (quadrant && (<div key={key} className={`p-2 rounded-xl border ${isDarkMode ? 'border-white/10 bg-white/5' : 'border-black/5 bg-gray-50/50'}`}><div className={`text-[8px] font-bold uppercase mb-0.5 ${theme.subText} opacity-70`}>{quadrant.label}</div><div className={`text-[10px] font-medium ${theme.text} leading-tight`}><TextRenderer content={quadrant.text} /></div></div>)) })}
                        </div>
                        <div className="absolute left-0 right-0 -bottom-1 h-6 flex items-center justify-center"><span className="text-[8px] font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1">{deepDiveData.matrix.xAxis} <ArrowRight size={10} /></span></div>
                    </div>
                    <div className={`pt-4 border-t ${isDarkMode ? 'border-white/10' : 'border-black/5'} mt-2`}><div className={`text-[13px] ${theme.subText} italic`}><TextRenderer content={deepDiveData.matrix.analysis} /></div></div>
                  </div>
                )}

                <div className={`p-6 rounded-[24px] relative overflow-hidden text-white ${isDarkMode ? "bg-indigo-900/40 border border-indigo-500/20" : "bg-indigo-900 border border-indigo-700"} shadow-xl`}>
                  <div className="absolute top-4 right-4 z-20"><button onClick={handleRefreshCaseStudy} disabled={loadingCaseStudy} className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-all active:scale-90"><RotateCw size={14} className={`text-white ${loadingCaseStudy ? 'animate-spin' : ''}`} /></button></div>
                  <div className="flex items-center gap-2 mb-4 opacity-80 relative z-10"><Building2 size={16} /><h3 className="text-[11px] font-bold uppercase tracking-widest">Case Study Thực tế</h3></div>
                  {loadingCaseStudy ? <div className="h-40 flex items-center justify-center text-white/50 gap-2"><Loader2 size={20} className="animate-spin" /><span className="text-sm">Đang tìm case study khác...</span></div> : (
                    <div className="relative z-10"><h4 className="text-[18px] font-bold mb-3 text-white leading-tight"><TextRenderer content={deepDiveData.caseStudyTitle} /></h4><div className="text-[14px] font-light text-gray-200"><TextRenderer content={deepDiveData.caseStudyContent} /></div></div>
                  )}
                </div>

                <div className={`${glassCardStyle} p-6`}>
                  <div className="flex items-center gap-2 mb-3"><PieChart size={16} className={theme.primary} /><h3 className={`text-[11px] font-bold uppercase tracking-widest ${theme.subText}`}>Số liệu chứng minh</h3></div>
                  <div className={`text-[26px] font-bold mb-2 leading-none ${theme.primary}`}>{deepDiveData.highlightStat}</div>
                  <div className={`text-[15px] ${theme.subText}`}><TextRenderer content={deepDiveData.stats} /></div>
                  <div className={`text-[10px] ${theme.subText} mt-2 pt-2 border-t ${isDarkMode ? 'border-white/10' : 'border-black/5'} opacity-70`}>Nguồn: <TextRenderer content={deepDiveData.source} /></div>
                </div>

                {deepDiveData.pitfalls && (
                  <div className={`${glassCardStyle} p-6`}>
                    <div className="flex items-center gap-2 mb-4"><AlertTriangle size={16} className="text-rose-500" /><h3 className="text-[11px] font-bold uppercase tracking-widest text-rose-500">Góc khuất & Sai lầm</h3></div>
                    <ul className="space-y-3">{deepDiveData.pitfalls.map((item, idx) => (<li key={idx} className={`flex gap-3 text-[14px] ${theme.text}`}><span className="flex-shrink-0 w-1.5 h-1.5 rounded-full mt-2 bg-rose-500"></span><div><TextRenderer content={item} /></div></li>))}</ul>
                  </div>
                )}

                <div className={`${glassCardStyle} p-6`}>
                  <div className="flex items-center gap-4 mb-4"><ListChecks size={16} className="text-emerald-500" /><h3 className="text-[11px] font-bold uppercase tracking-widest text-emerald-500">Hành động ngay</h3></div>
                  <ul className="space-y-3">{deepDiveData.actions.map((action, idx) => (<li key={idx} className={`flex gap-3 text-[14px] ${theme.text}`}><span className={`flex-shrink-0 w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-600 font-bold text-[10px] flex items-center justify-center mt-0.5`}>{idx + 1}</span><div><TextRenderer content={action} /></div></li>))}</ul>
                </div>
                
                {extraAnalysisCards.map((card, idx) => (
                  <div key={`extra-analysis-${idx}`} className={`animate-fade-in-up ${glassCardStyle} p-6`}>
                      <div className="flex items-center gap-2 mb-3"><Microscope size={16} className={theme.primary} /><h3 className={`text-[11px] font-bold uppercase tracking-widest ${theme.primary}`}>{card.lens}</h3></div>
                      <h4 className={`text-[18px] font-bold ${theme.text} mb-3 leading-tight`}>{card.title}</h4>
                      <div className={`${theme.text}`}><TextRenderer content={card.content} /></div>
                   </div>
                ))}
                
                <div ref={extraAnalysisEndRef} className="flex flex-row gap-3 justify-center mt-4 mb-10">
                   {(!quizData || quizData.length === 0) && !loadingQuiz && (
                     <button onClick={() => generateQuiz(false)} className={`flex-1 h-[50px] flex items-center justify-center gap-2 rounded-full ${isDarkMode ? "bg-white text-black hover:bg-gray-200" : "bg-black text-white hover:bg-gray-800"} shadow-lg hover:scale-[1.02] active:scale-95 transition-all font-bold text-[13px]`}><ClipboardList size={16} /><span>Kiểm tra</span></button>
                   )}
                   <button onClick={generateMoreAnalysis} disabled={loadingExtraAnalysis} className={`flex-1 h-[50px] flex items-center justify-center gap-2 rounded-full ${glassCardStyle} hover:scale-[1.02] active:scale-95 font-bold text-[13px] ${theme.primary}`}>{loadingExtraAnalysis ? <Loader2 size={16} className="animate-spin" /> : <Microscope size={16} />}<span>Phân tích thêm</span></button>
                </div>

                {loadingQuiz && (<div className="flex flex-col items-center justify-center py-12 space-y-3"><Loader2 size={30} className={`animate-spin ${theme.text}`} /><p className={`text-[13px] ${theme.subText}`}>Đang soạn đề thi...</p></div>)}

                {quizData && quizData.length > 0 && quizData[currentQuestionIndex] && (
                   <div ref={quizRef} className="mb-16 animate-fade-in-up">
                      <div className="flex items-center justify-between mb-4 px-2"><div className="flex items-center gap-2"><CheckCircle2 size={18} className="text-emerald-500" /><h3 className={`text-[13px] font-bold uppercase tracking-widest ${theme.subText}`}>Câu hỏi #{currentQuestionIndex + 1}</h3></div></div>
                      <div className={`${glassCardStyle} p-6`}>
                         <div className={`text-[16px] font-bold mb-6 ${theme.text} leading-relaxed`}><TextRenderer content={quizData[currentQuestionIndex].question} /></div>
                         <div className="space-y-3">
                            {quizData[currentQuestionIndex].options.map((opt, oIdx) => {
                               const isAnswered = userAnswers[currentQuestionIndex] !== undefined;
                               const isSelected = userAnswers[currentQuestionIndex] === oIdx;
                               const isCorrect = oIdx === quizData[currentQuestionIndex].correctIndex;
                               let btnClass = `w-full text-left p-4 rounded-xl text-[14px] border transition-all font-medium `;
                               if (isAnswered) {
                                  if (isCorrect) { btnClass += "bg-emerald-500/20 border-emerald-500 text-emerald-700 dark:text-emerald-400 "; } 
                                  else if (isSelected) { btnClass += "bg-rose-500/20 border-rose-500 text-rose-700 dark:text-rose-400 "; } 
                                  else { btnClass += `opacity-50 ${isDarkMode ? "border-white/10" : "border-black/10"}`; }
                               } else { btnClass += `hover:bg-gray-500/10 ${isDarkMode ? "border-white/10" : "border-black/10"} ${theme.text}`; }
                               return (
                                  <button key={oIdx} onClick={() => handleAnswerSelect(oIdx)} disabled={isAnswered} className={btnClass}>
                                     <div className="flex justify-between items-center"><div className="flex-1"><TextRenderer content={opt} /></div>{isAnswered && isCorrect && <CheckCircle2 size={18} className="text-emerald-600 flex-shrink-0 ml-2" />}{isAnswered && isSelected && !isCorrect && <XCircle size={18} className="text-rose-600 flex-shrink-0 ml-2" />}</div>
                                  </button>
                               );
                            })}
                         </div>
                         {userAnswers[currentQuestionIndex] !== undefined && (
                            <div className="mt-6 animate-fade-in">
                               <div className={`p-4 rounded-xl text-[14px] leading-relaxed mb-4 ${theme.text} ${isDarkMode ? "bg-white/5" : "bg-black/5"}`}><span className="font-bold block mb-1 uppercase text-[11px] tracking-wide opacity-70">Giải thích:</span><TextRenderer content={quizData[currentQuestionIndex].explanation} /></div>
                               <button onClick={handleNextQuestion} disabled={loadingQuiz} className={`w-full h-12 rounded-full flex items-center justify-center gap-2 font-bold text-[14px] transition-all active:scale-95 ${isDarkMode ? "bg-white text-black hover:bg-gray-200" : "bg-black text-white hover:bg-gray-800"}`}>{loadingQuiz ? <Loader2 size={18} className="animate-spin" /> : <><span>Câu tiếp theo</span> <ArrowRightCircle size={18} /></>}</button>
                            </div>
                         )}
                      </div>
                   </div>
                )}

                <div className={`w-full aspect-[9/16] ${glassCardStyle} relative flex flex-col items-center justify-center text-center p-8 overflow-hidden mb-8 group`}>
                   <div className="absolute top-4 right-4 z-20 opacity-0 group-hover:opacity-100 transition-opacity"><button onClick={handleRefreshInsight} disabled={loadingInsight} className={`p-2 rounded-full hover:bg-gray-500/20 transition-all active:scale-90`}><RotateCw size={16} className={`${theme.text} ${loadingInsight ? 'animate-spin' : ''}`} /></button></div>
                   <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-black/5 pointer-events-none" />
                   <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 opacity-80" />
                   <Quote size={28} className={`mb-8 flex-shrink-0 ${theme.subText}`} />
                   <div className={`font-serif-display italic w-full flex items-center justify-center ${theme.text}`}>{loadingInsight ? (<span className="text-lg opacity-50">Đang suy ngẫm...</span>) : (<TextRenderer content={`"${deepDiveData.insight}"`} className="w-full" paragraphClass="text-[24px] sm:text-[30px] md:text-[32px] leading-tight" />)}</div>
                </div>
              </div>
            )}

            {concept.relatedConcepts && concept.relatedConcepts.length > 0 && (
                <div className="mt-8 pt-8 border-t border-dashed border-gray-200/50">
                  <div className="flex items-center gap-2 mb-4"><Sparkles size={16} className={theme.primary} /><h3 className={`text-[13px] font-bold uppercase tracking-widest ${theme.subText}`}>Khám phá tiếp</h3></div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {concept.relatedConcepts.map((topic, idx) => {
                       const titleVn = typeof topic === 'string' ? topic : topic.vn;
                       const titleEn = typeof topic === 'string' ? "" : topic.en;
                       const query = typeof topic === 'string' ? topic : topic.en;
                       return (
                         <button key={idx} onClick={() => executeGeneration(query)} className={`w-full p-4 ${glassCardStyle} flex flex-col justify-center group hover:scale-[1.02] text-left relative overflow-hidden ${isDarkMode ? "hover:bg-white/10" : "hover:bg-white/80"}`}>
                            <div className="absolute right-3 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity"><ArrowRight size={16} className={theme.subText} /></div>
                            <span className={`text-[14px] font-bold mb-0.5 block pr-4`}>{titleVn}</span>
                            {titleEn && <span className={`text-[12px] ${theme.subText} font-medium block truncate pr-4 opacity-70`}>{titleEn}</span>}
                        </button>
                      )
                    })}
                  </div>
                </div>
            )}
          </div>
        )}
        {error && <div className="mt-8 p-4 rounded-[20px] bg-red-500/10 border border-red-500/20 text-center"><span className="text-[13px] font-medium text-rose-500">{error}</span></div>}
      </main>

      {!isModalOpen && !isQAModalOpen && (
        <div className="fixed bottom-6 left-0 right-0 flex justify-center items-center px-6 z-30 pointer-events-none">
          {!concept ? (
             <button onClick={() => executeGeneration('')} disabled={loading || !apiKey} className={`pointer-events-auto h-[45px] px-8 rounded-full flex items-center gap-3 shadow-[0_8px_32px_0_rgba(0,0,0,0.1)] border backdrop-blur-2xl transition-all duration-300 active:scale-95 ${loading || !apiKey ? 'bg-gray-100/50 text-gray-400 border-transparent' : `${isDarkMode ? "bg-black/20 text-white border-white/10 hover:bg-black/40" : "bg-white/20 text-black border-white/30 hover:bg-white/40"} hover:scale-105`}`}>
                {loading ? <Loader2 size={18} className="animate-spin" /> : <><Aperture size={18} strokeWidth={1.5} className={isDarkMode ? "text-white" : "text-black"} /><span className="text-[14px] font-medium tracking-wide">Học Ngẫu Nhiên</span></>}
             </button>
          ) : (
            <div className={`pointer-events-auto flex items-center justify-between p-1.5 rounded-full shadow-[0_8px_32px_0_rgba(0,0,0,0.1)] border backdrop-blur-2xl w-full max-w-[340px] transition-all duration-300 ${isDarkMode ? "bg-black/20 border-white/10" : "bg-white/20 border-white/30"}`}>
                <button onClick={handleProvoke} className={`flex-1 h-[38px] rounded-full flex items-center justify-center gap-1.5 transition-all duration-300 ${isProvokeMode ? (isDarkMode ? "bg-white text-black shadow-lg" : "bg-black text-white shadow-lg") : (isDarkMode ? "text-gray-400 hover:text-white" : "text-gray-500 hover:text-black")}`}>{loading && loadingStep === 'provoke' ? <Loader2 size={16} className="animate-spin" /> : <HelpCircle size={16} strokeWidth={isProvokeMode ? 2.5 : 2} />}<span className="text-[10px] font-medium whitespace-nowrap">Gợi Mở</span></button>
                <button onClick={handleQASubmit} className={`flex-1 h-[38px] rounded-full flex items-center justify-center gap-1.5 transition-all duration-300 mx-1 ${isDarkMode ? "text-gray-400 hover:text-white" : "text-gray-500 hover:text-black"}`}><MessageSquareText size={16} strokeWidth={2} /><span className="text-[10px] font-medium whitespace-nowrap">Hỏi Đáp</span></button>
                <button onClick={handleDeepDive} className={`flex-1 h-[38px] rounded-full flex items-center justify-center gap-1.5 transition-all duration-300 ${isDeepDiveMode ? (isDarkMode ? "bg-white text-black shadow-lg" : "bg-black text-white shadow-lg") : (isDarkMode ? "text-gray-400 hover:text-white" : "text-gray-500 hover:text-black")}`}>{loading && loadingStep === 'analyzing' ? <Loader2 size={16} className="animate-spin" /> : <Scan size={16} strokeWidth={isDeepDiveMode ? 2.5 : 2} />}<span className="text-[10px] font-medium whitespace-nowrap">Phân Tích</span></button>
            </div>
          )}
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
          <div className={`relative w-full max-w-sm ${glassCardStyle} ${isDarkMode ? "bg-[#141414]/90" : "bg-white/90"} p-6 shadow-2xl animate-fade-in-up`}>
            <div className="flex justify-between items-center mb-4"><h3 className={`text-[17px] font-semibold ${theme.text}`}>Chủ đề quan tâm</h3><button onClick={() => setIsModalOpen(false)} className={`p-1 rounded-full hover:bg-gray-500/10 ${theme.subText}`}><X size={20} /></button></div>
            <textarea className={`w-full h-24 p-4 rounded-xl ${theme.bg} border-none text-[16px] ${theme.text} placeholder:text-gray-500 focus:ring-2 focus:ring-indigo-500 resize-none outline-none mb-3`} placeholder="Ví dụ: Tài chính cá nhân, Chiến lược giá..." value={customPrompt} onChange={(e) => setCustomPrompt(e.target.value)} autoFocus />
            <div className="flex items-center justify-between mb-4"><button onClick={generateTopicSuggestions} disabled={loadingSuggestions} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full hover:bg-gray-500/10 transition-all border ${isDarkMode ? 'border-white/10' : 'border-black/5'}`}>{loadingSuggestions ? <Loader2 size={12} className="animate-spin" /> : <Wand2 size={12} className={theme.primary} />}<span className={`text-[11px] font-medium ${theme.primary}`}>Gợi ý chủ đề</span></button></div>
            {suggestedTopics.length > 0 && (<div className="flex flex-wrap gap-2 mb-6">{suggestedTopics.map((topic, idx) => (<button key={idx} onClick={() => setCustomPrompt(topic)} className={`text-[11px] px-3 py-1.5 rounded-full bg-gray-500/10 border border-transparent hover:border-gray-500/30 transition-all active:scale-95 ${theme.text}`}>{topic}</button>))}</div>)}
            <button onClick={() => executeGeneration(customPrompt)} className={`w-full h-[50px] ${isDarkMode ? "bg-white text-black hover:bg-gray-200" : "bg-black text-white hover:bg-gray-900"} rounded-full font-medium text-[15px] active:scale-95 transition-all`}>{customPrompt.trim() ? "Tạo bài học" : "Ngẫu nhiên"}</button>
          </div>
        </div>
      )}

      {isQAModalOpen && (
         <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setIsQAModalOpen(false)}></div>
            <div className={`relative w-full max-w-sm ${glassCardStyle} ${isDarkMode ? "bg-[#141414]/90" : "bg-white/90"} p-6 shadow-2xl animate-fade-in-up`}>
               <div className="flex justify-between items-center mb-4"><div className="flex items-center gap-2"><MessageSquareText size={20} className={theme.primary} /><h3 className={`text-[17px] font-semibold ${theme.text}`}>Hỏi đáp với chuyên gia</h3></div><button onClick={() => setIsQAModalOpen(false)} className={`p-1 rounded-full hover:bg-gray-500/10 ${theme.subText}`}><X size={20} /></button></div>
               <div className={`mb-4 px-3 py-2 rounded-lg border ${isDarkMode ? "border-white/10 bg-white/5" : "border-black/5 bg-black/5"} flex items-center gap-2`}><TrendingUp size={14} className={theme.subText} /><span className={`text-[12px] font-medium ${theme.subText} truncate`}>Chủ đề: {concept ? concept.titleVn : 'Chưa có bài học'}</span></div>
               <div className="relative">
                  <textarea className={`w-full h-24 p-4 pr-12 rounded-xl ${theme.bg} border-none text-[16px] ${theme.text} placeholder:text-gray-500 focus:ring-2 focus:ring-indigo-500 resize-none outline-none`} placeholder="Ví dụ: Giải thích lại phần ma trận? Áp dụng cho startup thế nào?" value={qaQuery} onChange={(e) => setQaQuery(e.target.value)} autoFocus onKeyDown={(e) => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleQASubmit(); }}} />
                  <button onClick={handleQASubmit} disabled={loadingQA || !qaQuery.trim()} className={`absolute bottom-3 right-3 p-2 rounded-full transition-all ${loadingQA || !qaQuery.trim() ? "bg-gray-500/20 text-gray-500" : `bg-indigo-600 text-white hover:bg-indigo-700 active:scale-90`}`}>{loadingQA ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}</button>
               </div>
               <p className={`mt-3 text-[12px] ${theme.subText} text-center opacity-70`}>Câu trả lời sẽ được lưu thành thẻ ở màn hình chính.</p>
            </div>
         </div>
      )}

      {lightboxImg && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setLightboxImg(null)}>
          <button className="absolute top-6 right-6 w-10 h-10 bg-gray-800/50 rounded-full flex items-center justify-center text-white hover:bg-gray-700" onClick={() => setLightboxImg(null)}><X size={20} /></button>
          <img src={lightboxImg} alt="Preview" className={`max-w-full max-h-full object-contain shadow-2xl rounded-lg transition-all duration-500 ${isDarkMode ? 'invert' : ''}`} onClick={(e) => e.stopPropagation()} />
        </div>
      )}
    </div>
  );
}