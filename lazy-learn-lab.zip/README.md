# Lazy Learn Lab

**Lazy Learn Lab** là một ứng dụng web học tập tương tác, sử dụng trí tuệ nhân tạo (AI) để tạo ra các bài học ngẫu nhiên, sâu sắc về các chủ đề phức tạp (Kinh doanh, Tâm lý học, Triết học...) dưới dạng dễ hiểu và trực quan.

Dự án áp dụng phong cách thiết kế **Monochromatic Crystal (Pha lê đơn sắc)** và hiệu ứng **Liquid Glass (Thủy tinh lỏng)** hiện đại.

---

## 1. Cấu Trúc Dự Án

Dự án được xây dựng trên nền tảng **React (TypeScript)** với cấu trúc file đơn giản:

```
/
├── index.html       # Entry point, chứa Tailwind CSS CDN và Import Map
├── index.tsx        # Mount React vào DOM
├── App.tsx          # Component chính chứa toàn bộ Logic và UI
├── types.ts         # Định nghĩa các Interface (TypeScript) cho dữ liệu
├── metadata.json    # Thông tin mô tả ứng dụng và quyền hạn
└── README.md        # Tài liệu dự án
```

---

## 2. Luồng Logic Chính (Core Logic)

### 2.1. Quản lý API Key Động
Hệ thống không hardcode API Key mà lấy động từ nguồn bên ngoài để đảm bảo tính liên tục và khả năng xoay vòng key (Key Rotation).

*   **Nguồn:** `https://data.rayma.vn/api.php?profile=google_api_data`
*   **Cơ chế:**
    1.  `useEffect` kích hoạt khi ứng dụng khởi chạy.
    2.  Fetch dữ liệu JSON từ URL.
    3.  Parse dữ liệu để tìm mảng các key (xử lý cả trường hợp JSON object hoặc mảng thuần).
    4.  Chọn ngẫu nhiên 1 key để sử dụng cho phiên làm việc.
    5.  **Trạng thái kết nối:** Hiển thị icon Wifi (Xanh/Đỏ) trên Header để báo trạng thái.

### 2.2. "Slot Machine" Brainstorming (Tạo bài học)
Khi người dùng bấm "Học Ngẫu Nhiên", hệ thống sử dụng cơ chế quay thưởng (Slot Machine) để tạo ra một tổ hợp ngẫu nhiên làm đầu vào cho AI:
*   **Domain (Lĩnh vực):** Tâm lý học hành vi, Game Theory, Stoicism...
*   **Vibe (Phong cách):** Nghịch lý, Đen tối, Tối giản, Gây tranh cãi...
*   **Context (Ngữ cảnh):** Để thao túng, để tránh lừa đảo, trong hẹn hò...

### 2.3. AI Model & Prompt Engineering
Ứng dụng sử dụng trực tiếp REST API của Google Gemini và Imagen.

*   **Text Generation:** `gemini-2.5-flash-preview-09-2025`
    *   Sử dụng `responseMimeType: "application/json"` để đảm bảo AI trả về dữ liệu có cấu trúc.
    *   **Logic Prompt:** Được tinh chỉnh kỹ lưỡng cho từng tính năng:
        *   *Bài học chính:* Yêu cầu giải thích bình dân, đi thẳng vào vấn đề.
        *   *Phân tích sâu:* Yêu cầu ví dụ đời thường hài hước, Case Study có thật, Số liệu tách biệt, và Quote từ Triết gia.
        *   *Gợi mở:* Đóng vai Coach tâm lý để đặt câu hỏi tự vấn (Self-reflection).
*   **Image Generation:** `imagen-4.0-generate-001`
    *   Tạo ảnh trừu tượng (Abstract 3D Geometric) dựa trên `visualPrompt` mà Gemini sinh ra.
    *   Style: Dark Surrealism, Cinematic Lighting, Monochromatic Indigo.

### 2.4. Các Tính Năng Chi Tiết
1.  **Học Ngẫu Nhiên:** Tạo khái niệm mới + Ảnh minh họa.
2.  **Phân Tích (Deep Dive):**
    *   Ví dụ đời thường (Humorous/Relatable).
    *   Ma trận chiến lược 2x2.
    *   Case Study thực tế.
    *   Số liệu chứng minh & Nguồn.
    *   Góc khuất (Pitfalls) & Hành động (Actions).
    *   Quote triết gia & Phân tích thêm dưới các lăng kính khác nhau.
3.  **Gợi Mở (Provoke):** Câu hỏi tự vấn, Góc nhìn phản biện, Thử thách 24h.
4.  **Kiểm Tra (Quiz):** Trắc nghiệm kiến thức vừa học.
5.  **Hỏi Đáp (Q&A):** Chat với AI trong ngữ cảnh bài học hiện tại.

---

## 3. Hệ Thống UI/UX (Design System)

Giao diện được chuẩn hóa theo phong cách **Liquid Glass** trên nền màu chủ đạo **Indigo**.

### 3.1. Màu Sắc & Theme
*   **Primary Color:** Indigo (`text-indigo-600` / `bg-indigo-600` ở Light mode, biến thể nhạt hơn ở Dark mode).
*   **Background:**
    *   Light: `bg-[#F0F2F5]` (Xám sáng sạch).
    *   Dark: `bg-[#050505]` (Đen sâu).
*   **Dark Mode:** Hỗ trợ chuyển đổi giao diện Sáng/Tối hoàn toàn.

### 3.2. Hiệu ứng Liquid Glass (Kính lỏng)
Tất cả các thẻ (Card), Header, và Bottom Bar đều sử dụng chung một công thức CSS (thông qua biến `glassCardStyle`):
*   `backdrop-blur-xl`: Độ mờ nền cao.
*   `bg-white/60` (Light) hoặc `bg-white/5` (Dark): Độ trong suốt cao để lộ nền.
*   `border-white/40`: Viền trắng mờ tạo cảm giác cạnh kính mài.
*   `shadow`: Bóng đổ mềm tạo chiều sâu.

### 3.3. Bố cục (Layout)
*   **Mobile-First:** Tối ưu cho màn hình dọc.
*   **Header:** Chiều cao tối giản (`44px`) để dành không gian cho nội dung.
*   **Bottom Bar:** Thanh điều hướng nổi (Floating Action Bar), kích thước nhỏ gọn.
*   **Typography:** Sử dụng font `Inter` cho văn bản chính và `Playfair Display` (Serif) cho các câu Quote hoặc số thứ tự nghệ thuật.

---

## 4. Công Nghệ Sử Dụng

*   **Frontend Framework:** React 19.
*   **Styling:** Tailwind CSS (qua CDN).
*   **Icons:** Lucide React.
*   **AI Services:** Google Gemini API & Google Imagen API.
*   **Build Tool:** Vite (hoặc môi trường tương thích ES Modules).

---

## 5. Định Nghĩa Dữ Liệu (TypeScript Interface)

Các Interface chính trong `types.ts`:
*   `Concept`: Cấu trúc dữ liệu bài học chính.
*   `DeepDiveData`: Dữ liệu phân tích sâu (Example, Matrix, CaseStudy...).
*   `QuizQuestion`: Cấu trúc câu hỏi trắc nghiệm.
*   `ProvokeData`: Dữ liệu câu hỏi gợi mở.
*   `QAItem`: Dữ liệu hội thoại hỏi đáp.
*   `SlotConfig`: Cấu hình đầu vào cho Slot Machine.
