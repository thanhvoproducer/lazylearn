export interface SlotConfig {
  domain: string;
  vibe: string;
  context: string;
}

export interface Difficulty {
  level: number;
  label: string;
}

export interface RelatedConcept {
  vn: string;
  en?: string;
}

export interface Concept {
  category: string;
  titleEn: string;
  titleVn: string;
  tag: string;
  shortLesson: string;
  detailedExplanation: string;
  visualPrompt: string;
  difficulty: Difficulty;
  relatedConcepts: (string | RelatedConcept)[];
}

export interface MatrixQuadrant {
  label: string;
  text: string;
}

export interface Matrix {
  yAxis: string;
  xAxis: string;
  q1?: MatrixQuadrant;
  q2?: MatrixQuadrant;
  q3?: MatrixQuadrant;
  q4?: MatrixQuadrant;
  analysis: string;
}

export interface DeepDiveData {
  realLifeExample: string;
  matrix?: Matrix;
  caseStudyTitle: string;
  caseStudyContent: string;
  highlightStat: string;
  stats: string;
  source: string;
  pitfalls?: string[];
  actions: string[];
  insight: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface ProvokeData {
  questions: string[];
  counter_argument?: string;
  mini_challenge?: string;
}

export interface ExtraAnalysisCard {
  title: string;
  lens: string;
  content: string;
}

export interface ExtraProvocationCard {
  title: string;
  content: string;
}

export interface QAItem {
  id: number;
  question: string;
  answer: string;
  isOpen: boolean;
}

export interface Theme {
  bg: string;
  text: string;
  subText: string;
  cardBg: string;
  cardBorder: string;
  headerBg: string;
  headerBorder: string;
  iconBg: string;
  inputBg: string;
  buttonText: string;
  accentBlue: string;
  accentPurple: string;
  accentOrange: string;
  accentTeal: string;
  accentRed: string;
  accentCyan: string;
  accentGreen: string;
}
